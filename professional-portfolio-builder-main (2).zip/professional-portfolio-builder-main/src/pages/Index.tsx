import { useState } from "react";
import { usePortfolio } from "@/hooks/usePortfolio";
import PortfolioForm from "@/components/portfolio/PortfolioForm";
import PortfolioView from "@/components/portfolio/PortfolioView";

const Index = () => {
  const { data, update, hasData } = usePortfolio();
  const [mode, setMode] = useState<"form" | "preview">(hasData ? "preview" : "form");

  if (mode === "preview" && hasData) {
    return <PortfolioView data={data} onEdit={() => setMode("form")} />;
  }

  return <PortfolioForm data={data} onSave={update} onPreview={() => setMode("preview")} />;
};

export default Index;
