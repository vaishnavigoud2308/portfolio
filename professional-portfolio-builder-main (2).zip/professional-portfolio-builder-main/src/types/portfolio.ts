export interface Project {
  id: string;
  title: string;
  description: string;
  link: string;
}

export interface Certification {
  id: string;
  title: string;
  imageData: string; // base64
}

export interface PortfolioData {
  name: string;
  role: string;
  introduction: string;
  about: string;
  skills: string[];
  projects: Project[];
  certifications: Certification[];
  contactEmail: string;
  phone: string;
  linkedin: string;
  github: string;
}

export const defaultPortfolio: PortfolioData = {
  name: "",
  role: "",
  introduction: "",
  about: "",
  skills: [],
  projects: [],
  certifications: [],
  contactEmail: "",
  phone: "",
  linkedin: "",
  github: "",
};
