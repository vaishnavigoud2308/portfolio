import AnimatedSection from "./AnimatedSection";
import { motion } from "framer-motion";
import { User } from "lucide-react";

interface Props {
  about: string;
}

const AboutSection = ({ about }: Props) => (
  <AnimatedSection id="about" className="section-padding max-w-5xl mx-auto">
    <div className="grid md:grid-cols-[auto_1fr] gap-10 items-start">
      <div className="hidden md:flex w-16 h-16 rounded-2xl bg-accent items-center justify-center shrink-0">
        <User size={28} className="text-accent-foreground" />
      </div>
      <div>
        <h2 className="text-3xl md:text-4xl font-heading font-bold text-foreground mb-2">About Me</h2>
        <div className="w-16 h-1 bg-primary rounded-full mb-8" />
        <p className="text-base md:text-lg text-muted-foreground leading-relaxed whitespace-pre-line">
          {about}
        </p>
      </div>
    </div>
  </AnimatedSection>
);

export default AboutSection;