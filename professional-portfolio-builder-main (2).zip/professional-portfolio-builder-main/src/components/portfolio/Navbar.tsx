import { useState } from "react";
import { Menu, X } from "lucide-react";

const links = [
  { label: "About", href: "#about" },
  { label: "Skills", href: "#skills" },
  { label: "Projects", href: "#projects" },
  { label: "Certifications", href: "#certifications" },
  { label: "Contact", href: "#contact" },
];

interface Props {
  name: string;
  onEdit: () => void;
}

const Navbar = ({ name, onEdit }: Props) => {
  const [open, setOpen] = useState(false);

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 glass">
      <div className="max-w-6xl mx-auto flex items-center justify-between px-6 py-4">
        <a href="#hero" className="font-heading text-xl font-bold text-foreground">
          {name || "Portfolio"}
        </a>

        {/* Desktop */}
        <div className="hidden md:flex items-center gap-8">
          {links.map((l) => (
            <a
              key={l.href}
              href={l.href}
              className="text-sm font-medium text-muted-foreground hover:text-primary transition-colors relative group"
            >
              {l.label}
              <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-primary rounded-full transition-all duration-300 group-hover:w-full" />
            </a>
          ))}
          <button
            onClick={onEdit}
            className="px-4 py-2 rounded-lg text-sm font-medium bg-primary text-primary-foreground hover:shadow-glow transition-all duration-300"
          >
            Edit
          </button>
        </div>

        {/* Mobile toggle */}
        <button className="md:hidden text-foreground" onClick={() => setOpen(!open)}>
          {open ? <X size={22} /> : <Menu size={22} />}
        </button>
      </div>

      {open && (
        <div className="md:hidden border-t border-border/50 bg-card/95 backdrop-blur-xl px-6 pb-4 space-y-3">
          {links.map((l) => (
            <a
              key={l.href}
              href={l.href}
              onClick={() => setOpen(false)}
              className="block text-sm text-muted-foreground hover:text-primary transition-colors py-1"
            >
              {l.label}
            </a>
          ))}
          <button
            onClick={() => { setOpen(false); onEdit(); }}
            className="block text-sm font-medium text-primary"
          >
            Edit Portfolio
          </button>
        </div>
      )}
    </nav>
  );
};

export default Navbar;