import { motion } from "framer-motion";
import { ArrowDown, Sparkles } from "lucide-react";

interface Props {
  name: string;
  role: string;
  introduction: string;
}

const HeroSection = ({ name, role, introduction }: Props) => (
  <section id="hero" className="relative min-h-screen flex flex-col justify-center max-w-5xl mx-auto px-6 md:px-12 lg:px-24 pt-24 overflow-hidden">
    {/* Background decorations */}
    <div className="absolute top-20 right-0 w-72 h-72 bg-primary/5 rounded-full blur-3xl" />
    <div className="absolute bottom-20 left-0 w-96 h-96 bg-accent/40 rounded-full blur-3xl" />
    <div className="absolute inset-0 dot-pattern opacity-40" />

    <div className="relative z-10">
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1, duration: 0.5 }}
        className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-accent text-accent-foreground text-sm font-medium mb-6"
      >
        <Sparkles size={14} />
        Available for work
      </motion.div>

      <motion.h1
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2, duration: 0.6 }}
        className="text-5xl md:text-7xl lg:text-8xl font-heading font-bold text-foreground mb-4 leading-[1.05]"
      >
        Hi, I'm{" "}
        <span className="gradient-text">{name}</span>
      </motion.h1>

      <motion.p
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.35, duration: 0.6 }}
        className="text-xl md:text-2xl text-muted-foreground font-body font-light mb-6 max-w-2xl"
      >
        {role}
      </motion.p>

      <motion.p
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.5, duration: 0.6 }}
        className="text-base md:text-lg text-muted-foreground max-w-2xl leading-relaxed mb-10"
      >
        {introduction}
      </motion.p>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.65, duration: 0.5 }}
        className="flex items-center gap-4"
      >
        <a
          href="#contact"
          className="inline-flex items-center gap-2 px-8 py-3.5 rounded-xl bg-primary text-primary-foreground font-medium text-sm hover:shadow-glow transition-all duration-300 hover:-translate-y-0.5"
        >
          Get in Touch
        </a>
        <a
          href="#projects"
          className="inline-flex items-center gap-2 px-8 py-3.5 rounded-xl border border-border text-foreground font-medium text-sm hover:bg-accent transition-all duration-300"
        >
          View Projects
        </a>
      </motion.div>
    </div>

    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ delay: 1.2 }}
      className="absolute bottom-10 left-1/2 -translate-x-1/2 animate-float"
    >
      <ArrowDown size={20} className="text-muted-foreground" />
    </motion.div>
  </section>
);

export default HeroSection;