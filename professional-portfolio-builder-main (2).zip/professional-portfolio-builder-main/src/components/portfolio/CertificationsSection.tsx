import AnimatedSection from "./AnimatedSection";
import { motion } from "framer-motion";
import { Certification } from "@/types/portfolio";
import { Award } from "lucide-react";

interface Props {
  certifications: Certification[];
}

const CertificationsSection = ({ certifications }: Props) => (
  <AnimatedSection id="certifications" className="section-padding max-w-5xl mx-auto">
    <div className="grid md:grid-cols-[auto_1fr] gap-10 items-start">
      <div className="hidden md:flex w-16 h-16 rounded-2xl bg-accent items-center justify-center shrink-0">
        <Award size={28} className="text-accent-foreground" />
      </div>
      <div>
        <h2 className="text-3xl md:text-4xl font-heading font-bold text-foreground mb-2">Certifications</h2>
        <div className="w-16 h-1 bg-primary rounded-full mb-10" />
        <div className="grid gap-6 sm:grid-cols-2 md:grid-cols-3">
          {certifications.map((c, i) => (
            <motion.div
              key={c.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.08, duration: 0.4 }}
              whileHover={{ y: -4 }}
              className="rounded-2xl overflow-hidden bg-card shadow-card border border-border/50 hover:shadow-lg hover:border-primary/20 transition-all duration-300"
            >
              <div className="relative">
                <img
                  src={c.imageData}
                  alt={c.title}
                  className="w-full h-48 object-cover"
                  loading="lazy"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-foreground/10 to-transparent" />
              </div>
              <div className="p-4 flex items-center gap-2">
                <Award size={14} className="text-primary shrink-0" />
                <p className="text-sm font-medium text-foreground truncate">{c.title}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  </AnimatedSection>
);

export default CertificationsSection;