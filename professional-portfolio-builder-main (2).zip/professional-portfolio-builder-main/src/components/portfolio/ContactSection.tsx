import AnimatedSection from "./AnimatedSection";
import { useState } from "react";
import { Mail, Phone, Linkedin, Github, Send, MessageSquare } from "lucide-react";
import { toast } from "sonner";

interface Props {
  email: string;
  phone: string;
  linkedin: string;
  github: string;
}

const ContactSection = ({ email, phone, linkedin, github }: Props) => {
  const [form, setForm] = useState({ name: "", email: "", message: "" });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const msgs = JSON.parse(localStorage.getItem("contact_messages") || "[]");
    msgs.push({ ...form, date: new Date().toISOString() });
    localStorage.setItem("contact_messages", JSON.stringify(msgs));
    toast.success("Message sent! Thank you for reaching out.");
    setForm({ name: "", email: "", message: "" });
  };

  const infoItems = [
    { icon: Mail, value: email, href: `mailto:${email}`, label: "Email" },
    { icon: Phone, value: phone, href: `tel:${phone}`, label: "Phone" },
    { icon: Linkedin, value: linkedin, href: linkedin, label: "LinkedIn" },
    { icon: Github, value: github, href: github, label: "GitHub" },
  ].filter((i) => i.value);

  const inputClass =
    "w-full px-4 py-3.5 rounded-xl bg-background border border-border text-foreground text-sm placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary transition-all duration-200";

  return (
    <AnimatedSection id="contact" className="section-padding max-w-5xl mx-auto">
      <div className="grid md:grid-cols-[auto_1fr] gap-10 items-start">
        <div className="hidden md:flex w-16 h-16 rounded-2xl bg-accent items-center justify-center shrink-0">
          <MessageSquare size={28} className="text-accent-foreground" />
        </div>
        <div>
          <h2 className="text-3xl md:text-4xl font-heading font-bold text-foreground mb-2">Get in Touch</h2>
          <div className="w-16 h-1 bg-primary rounded-full mb-10" />

          <div className="grid md:grid-cols-2 gap-12">
            {/* Info */}
            <div className="space-y-6">
              <p className="text-muted-foreground leading-relaxed">
                Have a question or want to work together? Drop me a message and I'll get back to you as soon as possible.
              </p>
              <div className="space-y-4">
                {infoItems.map((item, i) => (
                  <a
                    key={i}
                    href={item.href}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-4 p-3 rounded-xl hover:bg-accent/50 transition-colors group"
                  >
                    <div className="w-10 h-10 rounded-xl bg-accent flex items-center justify-center group-hover:bg-primary/10 transition-colors">
                      <item.icon size={18} className="text-accent-foreground group-hover:text-primary transition-colors" />
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground">{item.label}</p>
                      <p className="text-sm text-foreground break-all">{item.value}</p>
                    </div>
                  </a>
                ))}
              </div>
            </div>

            {/* Form */}
            <form onSubmit={handleSubmit} className="space-y-4">
              <input
                type="text"
                placeholder="Your Name"
                required
                maxLength={100}
                value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
                className={inputClass}
              />
              <input
                type="email"
                placeholder="Your Email"
                required
                maxLength={255}
                value={form.email}
                onChange={(e) => setForm({ ...form, email: e.target.value })}
                className={inputClass}
              />
              <textarea
                placeholder="Your Message"
                required
                maxLength={1000}
                rows={5}
                value={form.message}
                onChange={(e) => setForm({ ...form, message: e.target.value })}
                className={`${inputClass} resize-none`}
              />
              <button
                type="submit"
                className="inline-flex items-center gap-2 px-8 py-3.5 rounded-xl bg-primary text-primary-foreground font-medium text-sm hover:shadow-glow transition-all duration-300 hover:-translate-y-0.5"
              >
                <Send size={16} />
                Send Message
              </button>
            </form>
          </div>
        </div>
      </div>
    </AnimatedSection>
  );
};

export default ContactSection;