import AnimatedSection from "./AnimatedSection";
import { motion } from "framer-motion";
import { ExternalLink, FolderOpen, ArrowUpRight } from "lucide-react";
import { Project } from "@/types/portfolio";

interface Props {
  projects: Project[];
}

const ProjectsSection = ({ projects }: Props) => (
  <AnimatedSection id="projects" className="section-padding max-w-5xl mx-auto">
    <div className="grid md:grid-cols-[auto_1fr] gap-10 items-start">
      <div className="hidden md:flex w-16 h-16 rounded-2xl bg-accent items-center justify-center shrink-0">
        <FolderOpen size={28} className="text-accent-foreground" />
      </div>
      <div>
        <h2 className="text-3xl md:text-4xl font-heading font-bold text-foreground mb-2">Projects</h2>
        <div className="w-16 h-1 bg-primary rounded-full mb-10" />
        <div className="grid gap-6 md:grid-cols-2">
          {projects.map((p, i) => (
            <motion.div
              key={p.id}
              initial={{ opacity: 0, y: 24 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.08, duration: 0.4 }}
              whileHover={{ y: -4 }}
              className="group p-6 rounded-2xl bg-card shadow-card border border-border/50 hover:shadow-lg hover:border-primary/20 transition-all duration-300"
            >
              <div className="flex items-start justify-between mb-3">
                <div className="w-10 h-10 rounded-xl bg-accent flex items-center justify-center">
                  <FolderOpen size={18} className="text-accent-foreground" />
                </div>
                {p.link && (
                  <a
                    href={p.link}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-muted-foreground hover:text-primary transition-colors"
                  >
                    <ArrowUpRight size={18} />
                  </a>
                )}
              </div>
              <h3 className="text-lg font-heading font-semibold text-foreground mb-2">{p.title}</h3>
              <p className="text-sm text-muted-foreground leading-relaxed">{p.description}</p>
              {p.link && (
                <a
                  href={p.link}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1.5 text-sm font-medium text-primary hover:text-primary/80 transition-colors mt-4"
                >
                  View Project <ExternalLink size={13} />
                </a>
              )}
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  </AnimatedSection>
);

export default ProjectsSection;