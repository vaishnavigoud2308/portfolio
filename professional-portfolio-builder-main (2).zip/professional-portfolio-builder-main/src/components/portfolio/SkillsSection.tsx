import AnimatedSection from "./AnimatedSection";
import { motion } from "framer-motion";
import { Zap } from "lucide-react";

interface Props {
  skills: string[];
}

const SkillsSection = ({ skills }: Props) => (
  <AnimatedSection id="skills" className="section-padding max-w-5xl mx-auto">
    <div className="grid md:grid-cols-[auto_1fr] gap-10 items-start">
      <div className="hidden md:flex w-16 h-16 rounded-2xl bg-accent items-center justify-center shrink-0">
        <Zap size={28} className="text-accent-foreground" />
      </div>
      <div>
        <h2 className="text-3xl md:text-4xl font-heading font-bold text-foreground mb-2">Skills</h2>
        <div className="w-16 h-1 bg-primary rounded-full mb-10" />
        <div className="flex flex-wrap gap-3">
          {skills.map((skill, i) => (
            <motion.span
              key={skill}
              initial={{ opacity: 0, scale: 0.85 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.04, duration: 0.3 }}
              whileHover={{ scale: 1.05, y: -2 }}
              className="px-5 py-2.5 rounded-xl bg-card text-foreground text-sm font-medium shadow-card border border-border/50 hover:shadow-glow hover:border-primary/30 transition-all duration-300 cursor-default"
            >
              {skill}
            </motion.span>
          ))}
        </div>
      </div>
    </div>
  </AnimatedSection>
);

export default SkillsSection;