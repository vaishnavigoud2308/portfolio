import { useState } from "react";
import { PortfolioData, Project, Certification } from "@/types/portfolio";
import { Plus, Trash2, Upload } from "lucide-react";
import { toast } from "sonner";

interface Props {
  data: PortfolioData;
  onSave: (data: Partial<PortfolioData>) => void;
  onPreview: () => void;
}

const PortfolioForm = ({ data, onSave, onPreview }: Props) => {
  const [skillInput, setSkillInput] = useState("");

  const addSkill = () => {
    const s = skillInput.trim();
    if (s && !data.skills.includes(s)) {
      onSave({ skills: [...data.skills, s] });
      setSkillInput("");
    }
  };

  const removeSkill = (skill: string) => {
    onSave({ skills: data.skills.filter((s) => s !== skill) });
  };

  const addProject = () => {
    const p: Project = { id: crypto.randomUUID(), title: "", description: "", link: "" };
    onSave({ projects: [...data.projects, p] });
  };

  const updateProject = (id: string, field: keyof Project, value: string) => {
    onSave({
      projects: data.projects.map((p) => (p.id === id ? { ...p, [field]: value } : p)),
    });
  };

  const removeProject = (id: string) => {
    onSave({ projects: data.projects.filter((p) => p.id !== id) });
  };

  const handleCertUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 2 * 1024 * 1024) {
      toast.error("File must be under 2MB");
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      const cert: Certification = {
        id: crypto.randomUUID(),
        title: file.name.replace(/\.[^.]+$/, ""),
        imageData: reader.result as string,
      };
      onSave({ certifications: [...data.certifications, cert] });
    };
    reader.readAsDataURL(file);
    e.target.value = "";
  };

  const removeCert = (id: string) => {
    onSave({ certifications: data.certifications.filter((c) => c.id !== id) });
  };

  const inputClass =
    "w-full px-4 py-3 rounded-lg bg-card border border-border text-foreground text-sm placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring";
  const labelClass = "block text-sm font-medium text-foreground mb-1.5";

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-2xl mx-auto px-6 py-16">
        <h1 className="text-4xl md:text-5xl font-heading text-foreground mb-2">Build Your Portfolio</h1>
        <p className="text-muted-foreground mb-12">Fill in your details to generate a professional portfolio.</p>

        <div className="space-y-10">
          {/* Basic Info */}
          <section className="space-y-4">
            <h2 className="text-xl font-heading text-foreground">Basic Info</h2>
            <div>
              <label className={labelClass}>Full Name *</label>
              <input className={inputClass} placeholder="John Doe" value={data.name} onChange={(e) => onSave({ name: e.target.value })} required />
            </div>
            <div>
              <label className={labelClass}>Role / Title *</label>
              <input className={inputClass} placeholder="Full Stack Developer" value={data.role} onChange={(e) => onSave({ role: e.target.value })} />
            </div>
            <div>
              <label className={labelClass}>Introduction</label>
              <textarea className={`${inputClass} resize-none`} rows={3} placeholder="A short tagline..." value={data.introduction} onChange={(e) => onSave({ introduction: e.target.value })} />
            </div>
            <div>
              <label className={labelClass}>About</label>
              <textarea className={`${inputClass} resize-none`} rows={5} placeholder="Tell your story..." value={data.about} onChange={(e) => onSave({ about: e.target.value })} />
            </div>
          </section>

          {/* Skills */}
          <section className="space-y-4">
            <h2 className="text-xl font-heading text-foreground">Skills</h2>
            <div className="flex gap-2">
              <input
                className={inputClass}
                placeholder="e.g. React"
                value={skillInput}
                onChange={(e) => setSkillInput(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && (e.preventDefault(), addSkill())}
              />
              <button onClick={addSkill} className="px-4 py-3 rounded-lg bg-primary text-primary-foreground text-sm hover:bg-primary/90 transition-colors">
                <Plus size={18} />
              </button>
            </div>
            <div className="flex flex-wrap gap-2">
              {data.skills.map((s) => (
                <span key={s} className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md bg-accent text-accent-foreground text-sm">
                  {s}
                  <button onClick={() => removeSkill(s)} className="text-muted-foreground hover:text-destructive transition-colors">
                    <Trash2 size={13} />
                  </button>
                </span>
              ))}
            </div>
          </section>

          {/* Projects */}
          <section className="space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-xl font-heading text-foreground">Projects</h2>
              <button onClick={addProject} className="inline-flex items-center gap-1.5 text-sm font-medium text-primary hover:text-primary/80 transition-colors">
                <Plus size={16} /> Add
              </button>
            </div>
            {data.projects.map((p) => (
              <div key={p.id} className="p-4 rounded-xl bg-card border border-border space-y-3">
                <div className="flex items-start justify-between">
                  <input className={inputClass} placeholder="Project Title" value={p.title} onChange={(e) => updateProject(p.id, "title", e.target.value)} />
                  <button onClick={() => removeProject(p.id)} className="ml-2 mt-3 text-muted-foreground hover:text-destructive transition-colors">
                    <Trash2 size={16} />
                  </button>
                </div>
                <textarea className={`${inputClass} resize-none`} rows={2} placeholder="Description" value={p.description} onChange={(e) => updateProject(p.id, "description", e.target.value)} />
                <input className={inputClass} placeholder="Link (https://...)" value={p.link} onChange={(e) => updateProject(p.id, "link", e.target.value)} />
              </div>
            ))}
          </section>

          {/* Certifications */}
          <section className="space-y-4">
            <h2 className="text-xl font-heading text-foreground">Certifications</h2>
            <label className="flex items-center gap-2 px-4 py-3 rounded-lg border-2 border-dashed border-border cursor-pointer hover:border-primary/40 transition-colors">
              <Upload size={18} className="text-muted-foreground" />
              <span className="text-sm text-muted-foreground">Upload certificate image (max 2MB)</span>
              <input type="file" accept="image/*" className="hidden" onChange={handleCertUpload} />
            </label>
            <div className="grid gap-4 sm:grid-cols-2">
              {data.certifications.map((c) => (
                <div key={c.id} className="relative rounded-xl overflow-hidden bg-card shadow-card group">
                  <img src={c.imageData} alt={c.title} className="w-full h-36 object-cover" />
                  <div className="p-3 flex items-center justify-between">
                    <input
                      className="text-sm font-medium text-foreground bg-transparent border-none focus:outline-none w-full"
                      value={c.title}
                      onChange={(e) =>
                        onSave({
                          certifications: data.certifications.map((x) =>
                            x.id === c.id ? { ...x, title: e.target.value } : x
                          ),
                        })
                      }
                    />
                    <button onClick={() => removeCert(c.id)} className="text-muted-foreground hover:text-destructive transition-colors">
                      <Trash2 size={14} />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </section>

          {/* Contact */}
          <section className="space-y-4">
            <h2 className="text-xl font-heading text-foreground">Contact Details</h2>
            <input className={inputClass} placeholder="Email" value={data.contactEmail} onChange={(e) => onSave({ contactEmail: e.target.value })} />
            <input className={inputClass} placeholder="Phone" value={data.phone} onChange={(e) => onSave({ phone: e.target.value })} />
            <input className={inputClass} placeholder="LinkedIn URL" value={data.linkedin} onChange={(e) => onSave({ linkedin: e.target.value })} />
            <input className={inputClass} placeholder="GitHub URL" value={data.github} onChange={(e) => onSave({ github: e.target.value })} />
          </section>

          {/* Actions */}
          <div className="flex gap-4 pt-4">
            <button
              onClick={() => {
                if (!data.name.trim()) {
                  toast.error("Please enter your name");
                  return;
                }
                onPreview();
              }}
              className="px-8 py-3 rounded-lg bg-primary text-primary-foreground font-medium text-sm hover:bg-primary/90 transition-colors"
            >
              Preview Portfolio
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PortfolioForm;
