import { PortfolioData } from "@/types/portfolio";
import Navbar from "./Navbar";
import HeroSection from "./HeroSection";
import AboutSection from "./AboutSection";
import SkillsSection from "./SkillsSection";
import ProjectsSection from "./ProjectsSection";
import CertificationsSection from "./CertificationsSection";
import ContactSection from "./ContactSection";

interface Props {
  data: PortfolioData;
  onEdit: () => void;
}

const PortfolioView = ({ data, onEdit }: Props) => (
  <div className="min-h-screen bg-background">
    <Navbar name={data.name} onEdit={onEdit} />
    <HeroSection name={data.name} role={data.role} introduction={data.introduction} />
    {data.about && <AboutSection about={data.about} />}
    {data.skills.length > 0 && <SkillsSection skills={data.skills} />}
    {data.projects.length > 0 && <ProjectsSection projects={data.projects} />}
    {data.certifications.length > 0 && <CertificationsSection certifications={data.certifications} />}
    <ContactSection email={data.contactEmail} phone={data.phone} linkedin={data.linkedin} github={data.github} />
    <footer className="py-10 text-center text-xs text-muted-foreground border-t border-border/50">
      <p>© {new Date().getFullYear()} {data.name}. All rights reserved.</p>
      <p className="mt-1 text-muted-foreground/60">Built with ❤️</p>
    </footer>
  </div>
);

export default PortfolioView;