import { useState, useEffect, useCallback } from "react";
import { PortfolioData, defaultPortfolio } from "@/types/portfolio";

const STORAGE_KEY = "portfolio_data";

export function usePortfolio() {
  const [data, setData] = useState<PortfolioData>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      return saved ? { ...defaultPortfolio, ...JSON.parse(saved) } : defaultPortfolio;
    } catch {
      return defaultPortfolio;
    }
  });

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
  }, [data]);

  const update = useCallback((partial: Partial<PortfolioData>) => {
    setData((prev) => ({ ...prev, ...partial }));
  }, []);

  const hasData = data.name.trim().length > 0;

  return { data, update, hasData };
}
